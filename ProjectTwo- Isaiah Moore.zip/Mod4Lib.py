# Import necessary libraries from PyMongo and BSON
from pymongo import MongoClient
from bson.objectid import ObjectId

# Define animal shelter class
class AnimalShelter(object):
    def __init__(self, username, password):
        # Information to log in to specific database
        USER = 'aacuser'
        PASS = 'isaiah.moore2'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32191
        DB = 'AAC'
        COL = 'animals'

        # Create a MongoDB client with login and connection info
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=admin')
            
        # Access the database and collection
        self.database = self.client[DB]
        self.collection = self.database[COL]
            
        # Inform if connection was a success
        print("Connected to MongoDB")
            
    # Method to insert new document
    def create(self, data):
        if data is not None:
            # Attempt to insert data
            self.collection.insert_one(data)
            return True
            
        else:
            # Error for no provided data
            raise ValueError("Data parameter is empty")

    # Method to find and return documents that match query
    def read(self, query):
        if query is not None:
            # Use find to search collection and  return results
            documents = list(self.collection.find(query))
            return documents
            
        else:
            # Error for no provided query
            raise ValueError("Query parameter is empty")
            
    # Method to update multiple documents that match the query         
    def update(self, query, new_values):
        if query and new_values:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        else:
            # Requires query to update and new information to update to
            raise ValueError("Query and update parameters are required")
        
    # Method to delete multiple matching documents
    def delete(self, query):
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            # Missing query parameter error - what should be deleted?
            raise ValueError("Query parameter is required")
        
                
        